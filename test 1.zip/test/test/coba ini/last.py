import tkinter as tk
from tkinter import messagebox, StringVar, ttk, Canvas, Frame
import bcrypt
import json
import os
import datetime
from PIL import Image, ImageTk
import openpyxl

class LoginApp:
    def __init__(self, root):
        self.root = root
        self.root.title('Login')
        self.root.geometry('1166x718')
        self.root.config(bg='#001220')
        
        self.font1 = ('Helvetica', 25, 'bold')
        self.font2 = ('Arial', 17, 'bold')
        self.font3 = ('Arial', 13, 'bold')
        self.font4 = ('Arial', 17, 'bold', 'underline')

        self.current_user = None  # To store the logged-in username

        # Load the image and save reference
        self.image_path = os.path.join(os.path.dirname(__file__), "images", "Untitled design.png")
        self.photo = None
        self.load_image()

        self.show_signup_frame()

    def get_data_file_path(self):
        base_dir = os.path.dirname(__file__)
        return os.path.join(base_dir, "data.json")

    def save_data(self, data):
        current_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        data["Waktu Presensi"] = current_time
        with open(self.get_data_file_path(), "w") as file:
            json.dump(data, file, indent=4)

        self.save_data_to_excel()

    def load_data(self):
        try:
            data_file_path = self.get_data_file_path()
            if not os.path.exists(data_file_path) or os.stat(data_file_path).st_size == 0:
                with open(data_file_path, "w") as file:
                    json.dump({}, file)
                return {}
            with open(data_file_path, "r") as file:
                return json.load(file)
        except (FileNotFoundError, json.JSONDecodeError):
            return {}
        
    def save_data_to_excel(self):
        data = self.load_data()
        workbook = openpyxl.Workbook()
        worksheet = workbook.active

        # Tulis header
        worksheet['A1'] = 'Username'
        worksheet['B1'] = 'Name'
        worksheet['C1'] = 'NIM'
        worksheet['D1'] = 'Courses'
        worksheet['E1'] = 'Start Date'
        worksheet['F1'] = 'Week Number'
        worksheet['G1'] = 'Attendance Status'
        worksheet['H1'] = 'Alasan Ketidakhadiran'
        worksheet['I1'] = 'Waktu Presensi'

        row = 2
        for username, user_data in data.items():
            if isinstance(user_data, dict):
                worksheet.cell(row=row, column=1, value=username)
                worksheet.cell(row=row, column=2, value=user_data.get('name', ''))
                worksheet.cell(row=row, column=3, value=user_data.get('nim', ''))
                worksheet.cell(row=row, column=4, value=', '.join(user_data.get('courses', [])))
                worksheet.cell(row=row, column=5, value=user_data.get('start_date', ''))
                worksheet.cell(row=row, column=6, value=user_data.get('week_num', ''))
                attendance_data = user_data.get('attendance', {})
                worksheet.cell(row=row, column=7, value=attendance_data.get('attendance_status', ''))
                worksheet.cell(row=row, column=8, value=attendance_data.get('reason', ''))
            else:
                worksheet.cell(row=row, column=1, value=username)
            worksheet.cell(row=row, column=9, value=data.get('Waktu Presensi', ''))
            row += 1

        workbook.save('data.xlsx')

    def load_image(self):
        image = Image.open(self.image_path)
        image = image.resize((500, 718))  # Sesuaikan ukuran gambar
        self.photo = ImageTk.PhotoImage(image)

    def add_image_to_frame(self, frame):
        image_label = tk.Label(frame, image=self.photo, bg='#001220')
        image_label.place(relx=0.8, rely=0.5, anchor=tk.CENTER)

    def signup(self):
        username = self.username_entry.get()
        password = self.password_entry.get()
        data = self.load_data()
        if username != '' and password != '':
            if username in data:
                messagebox.showerror('Error', 'Username Telah Digunakan. Coba Username Lain.')
            else:
                hashed_password = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt())
                data[username] = {"password": hashed_password.decode('utf-8'), "courses": []}
                self.save_data(data)
                messagebox.showinfo('Success', 'Akun Berhasil Dibuat')
                self.show_login_frame()
        else:
            messagebox.showerror('Error', 'Enter all data.')

    def save_courses(self):
        name = self.name_entry.get()
        nim = self.nim_entry.get()
        courses = [entry.get() for entry in self.course_entries]

        data = self.load_data()
        if name and nim and self.current_user and all(courses):
            if self.current_user in data:
                data[self.current_user]["name"] = name
                data[self.current_user]["nim"] = nim
                data[self.current_user]["courses"] = courses
                self.save_data(data)
                messagebox.showinfo('Success', 'Courses and details have been saved.')
                self.show_course_selection_frame()  # Show the course selection frame after saving
            else:
                messagebox.showerror('Error', 'Invalid username.')
        else:
            messagebox.showerror('Error', 'Please fill in all fields.')

    def save_start_date_and_week_num(self):
        start_date = self.start_date_entry.get()
        week_num = self.week_num_entry.get()
        data = self.load_data()
        if start_date and week_num and self.current_user:
            if self.current_user in data:
                data[self.current_user]["start_date"] = start_date
                data[self.current_user]["week_num"] = week_num
                self.save_data(data)
                messagebox.showinfo('Success', 'Start date and week number have been saved.')
                self.show_attendance_frame()
            else:
                messagebox.showerror('Error', 'Invalid username.')
        else:
            messagebox.showerror('Error', 'Please fill in all fields.')

    def login(self):
        username = self.username_login_entry.get()
        password = self.password_login_entry.get()
        data = self.load_data()
        if username != '' and password != '':
            if username in data and bcrypt.checkpw(password.encode('utf-8'), data[username]['password'].encode('utf-8')):
                messagebox.showinfo('Success', 'Login Berhasil.')
                self.current_user = username  # Store the logged-in username
                self.show_course_input_frame()
                self.populate_course_data(data[username])  # Pre-populate course data
            else:
                messagebox.showerror('Error', 'Password atau Username Invalid')
        else:
            messagebox.showerror('Error', 'Enter all data.')

    def populate_course_data(self, user_data):
        self.name_entry.delete(0, 'end')
        self.name_entry.insert(0, user_data.get("name", ""))

        self.nim_entry.delete(0, 'end')
        self.nim_entry.insert(0, user_data.get("nim", ""))

        courses = user_data.get("courses", [])
        for i, entry in enumerate(self.course_entries):
            entry.delete(0, 'end')
            if i < len(courses):
                entry.insert(0, courses[i])

    def show_signup_frame(self):
        self.clear_frame()
        frame1 = tk.Frame(self.root, bg='#001220', width=583, height=718)
        frame1.place(x=0, y=0)

        signup_label = tk.Label(frame1, font=self.font1, text='Sign Up Akun Mahasiswa', bg='#001220', fg='#fff')
        signup_label.place(relx=0.5, rely=0.1, anchor=tk.CENTER)

        username_label = tk.Label(frame1, font=self.font3, text='Username:', bg='#001220', fg='#fff')
        username_label.place(relx=0.1, rely=0.3, anchor=tk.W)

        self.username_entry = tk.Entry(frame1, font=self.font2, fg='#FFFFFF', bg='#121111', insertbackground='#fff')
        self.username_entry.place(relx=0.3, rely=0.3, anchor=tk.W)

        password_label = tk.Label(frame1, font=self.font3, text='Password:', bg='#001220', fg='#fff')
        password_label.place(relx=0.1, rely=0.45, anchor=tk.W)

        self.password_entry = tk.Entry(frame1, font=self.font2, show='*', fg='#FFFFFF', bg='#121111', insertbackground='#fff')
        self.password_entry.place(relx=0.3, rely=0.45, anchor=tk.W)

        signup_button = tk.Button(frame1, command=self.signup, font=self.font2, text='Sign up', fg='#fff', bg='#00965d', activebackground='#006e44', width=12)
        signup_button.place(relx=0.5, rely=0.55, anchor=tk.CENTER)

        login_label = tk.Label(frame1, font=self.font3, text='Apakah sudah memiliki akun?', bg='#001220', fg='#fff')
        login_label.place(relx=0.5, rely=0.70, anchor=tk.CENTER)

        login_button = tk.Button(frame1, command=self.show_login_frame, font=self.font4, text='Login', fg='#fff', bg='#00965d', activebackground='#001220', width=8)
        login_button.place(relx=0.5, rely=0.75, anchor=tk.CENTER)
        
        self.add_image_to_frame(self.root)  # Menampilkan gambar di frame signup

    def show_login_frame(self):
        self.clear_frame()
        frame2 = tk.Frame(self.root, bg='#001220', width=583, height=718)
        frame2.place(x=0, y=0)

        login_label2 = tk.Label(frame2, font=self.font1, text='Log in', bg='#001220', fg='#fff')
        login_label2.place(relx=0.5, rely=0.1, anchor=tk.CENTER)

        username_label2 = tk.Label(frame2, font=self.font3, text='Username:', bg='#001220', fg='#fff')  # Perbaikan penulisan
        username_label2.place(relx=0.1, rely=0.3, anchor=tk.W)

        password_label2 = tk.Label(frame2, font=self.font3, text='Password:', bg='#001220', fg='#fff')
        password_label2.place(relx=0.1, rely=0.45, anchor=tk.W)

        self.username_login_entry = tk.Entry(frame2, font=self.font2, fg='#fff', bg='#121111', insertbackground='#fff')
        self.username_login_entry.place(relx=0.5, rely=0.3, anchor=tk.CENTER)

        self.password_login_entry = tk.Entry(frame2, font=self.font2, show='*', fg='#fff', bg='#121111', insertbackground='#fff')
        self.password_login_entry.place(relx=0.5, rely=0.45, anchor=tk.CENTER)

        login_button2 = tk.Button(frame2, command=self.login, font=self.font2, text='Login', fg='#fff', bg='#00965d', activebackground='#006e44', width=12)
        login_button2.place(relx=0.5, rely=0.6, anchor=tk.CENTER)

        self.add_image_to_frame(self.root)  # Menampilkan gambar di frame login

    def show_course_input_frame(self):
        self.clear_frame()
        frame3 = tk.Frame(self.root, bg='#001220', width=700, height=600)
        frame3.place(x=233, y=59)

        name_label = tk.Label(frame3, font=self.font3, text='Name:', bg='#001220', fg='#fff')
        name_label.place(x=20, y=20)
        self.name_entry = tk.Entry(frame3, font=self.font2, fg='#FFFFFF', bg='#121111', insertbackground='#fff', width=30)
        self.name_entry.place(x=120, y=20)

        nim_label = tk.Label(frame3, font=self.font3, text='NIM:', bg='#001220', fg='#fff')
        nim_label.place(x=20, y=70)
        self.nim_entry = tk.Entry(frame3, font=self.font2, fg='#FFFFFF', bg='#121111', insertbackground='#fff', width=30)
        self.nim_entry.place(x=120, y=70)

        course_labels = ['Course 1:', 'Course 2:', 'Course 3:', 'Course 4:', 'Course 5:', 'Course 6:', 'Course 7:', 'Course 8:', 'Course 9:', 'Course 10:', 'Course 11:']
        self.course_entries = []

        for i, course_label in enumerate(course_labels):
            label = tk.Label(frame3, font=self.font3, text=course_label, bg='#001220', fg='#fff')
            label.place(x=20, y=120 + i * 30)
            entry = tk.Entry(frame3, font=self.font2, fg='#FFFFFF', bg='#121111', insertbackground='#fff', width=30)
            entry.place(x=120, y=120 + i * 30)
            self.course_entries.append(entry)

        self.save_button = tk.Button(frame3, command=self.save_courses, font=self.font2, text='Save', fg='#fff', bg='#00965d', activebackground='#006e44', width=12)
        self.save_button.place(relx=0.5, rely=0.9, anchor=tk.CENTER)
        
        self.add_image_to_frame(self.root)  # Menampilkan gambar di frame input course

    def show_course_selection_frame(self):
        self.clear_frame()
        frame4 = tk.Frame(self.root, bg='#001220', width=700, height=600)
        frame4.place(x=233, y=59)

        selection_label = tk.Label(frame4, font=self.font1, text='Select Courses', bg='#001220', fg='#fff')
        selection_label.place(relx=0.5, rely=0.1, anchor=tk.CENTER)

        canvas = Canvas(frame4, bg='#001220', highlightthickness=0)
        canvas.place(relwidth=0.95, relheight=0.7, rely=0.2, relx=0.025)

        scrollbar = ttk.Scrollbar(frame4, orient="vertical", command=canvas.yview)
        scrollbar.place(relx=0.975, rely=0.2, relheight=0.7, anchor="ne")
        canvas.configure(yscrollcommand=scrollbar.set)

        scrollable_frame = Frame(canvas, bg='#001220')
        scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(
                scrollregion=canvas.bbox("all")
            )
        )
        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")

        data = self.load_data()
        user_data = data.get(self.current_user, {})
        courses = user_data.get("courses", [])

        self.selected_courses = []

        for i, course in enumerate(courses):
            var = StringVar(value=course)
            checkbox = ttk.Checkbutton(scrollable_frame, text=course, variable=var, onvalue=course, offvalue="")
            checkbox.pack(anchor=tk.W, pady=5)
            self.selected_courses.append(var)

        save_selection_button = tk.Button(frame4, command=self.show_start_date_and_week_num_frame, font=self.font2, text='Next', fg='#fff', bg='#00965d', activebackground='#006e44', width=15)
        save_selection_button.place(relx=0.5, rely=0.95, anchor=tk.CENTER)  # Memastikan tombol tidak menghalangi

        self.add_image_to_frame(self.root)  # Menampilkan gambar di frame selection course

    def show_start_date_and_week_num_frame(self):
        selected_courses = [var.get() for var in self.selected_courses if var.get()]
        data = self.load_data()

        if self.current_user in data:
            data[self.current_user]["selected_courses"] = selected_courses
            self.save_data(data)
        else:
            messagebox.showerror('Error', 'Invalid username.')

        self.clear_frame()
        frame5 = tk.Frame(self.root, bg='#001220', width=700, height=600)
        frame5.place(x=233, y=59)

        start_date_label = tk.Label(frame5, font=self.font3, text='Start Date:', bg='#001220', fg='#fff')
        start_date_label.place(x=2, y=20)
        self.start_date_entry = tk.Entry(frame5, font=self.font2, fg='#FFFFFF', bg='#121111', insertbackground='#fff', width=30)
        self.start_date_entry.place(x=127, y=20)

        week_num_label = tk.Label(frame5, font=self.font3, text='Week Number:', bg='#001220', fg='#fff')
        week_num_label.place(x=2, y=70)
        self.week_num_entry = tk.Entry(frame5, font=self.font2, fg='#FFFFFF', bg='#121111', insertbackground='#fff', width=30)
        self.week_num_entry.place(x=127, y=70)

        save_button = tk.Button(frame5, command=self.save_start_date_and_week_num, font=self.font2, text='Save', fg='#fff', bg='#00965d', activebackground='#006e44', width=12)
        save_button.place(relx=0.5, rely=0.9, anchor=tk.CENTER)

        self.add_image_to_frame(self.root)  # Menampilkan gambar di frame input start date dan week number

    def show_attendance_frame(self):
        self.clear_frame()
        frame6 = tk.Frame(self.root, bg='#001220', width=700, height=600)
        frame6.place(x=133, y=59)

        attendance_label = tk.Label(frame6, font=self.font1, text='Attendance', bg='#001220', fg='#fff')
        attendance_label.place(relx=0.5, rely=0.1, anchor=tk.CENTER)

        self.attendance_status = StringVar(value="Hadir")  # Default set to 'Hadir'
        ttk.Radiobutton(frame6, text="Hadir", value="Hadir", variable=self.attendance_status, style="TRadiobutton").place(relx=0.4, rely=0.3, anchor=tk.CENTER)
        ttk.Radiobutton(frame6, text="Tidak Hadir", value="Tidak Hadir", variable=self.attendance_status, style="TRadiobutton").place(relx=0.6, rely=0.3, anchor=tk.CENTER)

        reason_label = tk.Label(frame6, font=self.font3, text='Alasan Ketidakhadiran:', bg='#001220', fg='#fff')
        reason_label.place(relx=0.5, rely=0.4, anchor=tk.CENTER)
        self.reason_entry = tk.Entry(frame6, font=self.font2, fg='#FFFFFF', bg='#121111', insertbackground='#fff', width=30)
        self.reason_entry.place(relx=0.5, rely=0.4, anchor=tk.CENTER)

        save_attendance_button = tk.Button(frame6, command=self.save_attendance, font=self.font2, text='Save', fg='#fff', bg='#00965d', activebackground='#006e44', width=12)
        save_attendance_button.place(relx=0.1, rely=0.1, anchor=tk.CENTER)

        self.add_image_to_frame(self.root)  # Menampilkan gambar di frame input start date dan week number

    def show_attendance_frame(self):
        self.clear_frame()
        frame6 = tk.Frame(self.root, bg='#001220', width=700, height=600)
        frame6.place(x=133, y=59)

        attendance_label = tk.Label(frame6, font=self.font1, text='Attendance', bg='#001220', fg='#fff')
        attendance_label.place(relx=0.5, rely=0.1, anchor=tk.CENTER)

        self.attendance_status = StringVar(value="Hadir")  # Default set to 'Hadir'
        hadir_radio = ttk.Radiobutton(frame6, text="Hadir", value="Hadir", variable=self.attendance_status, style="TRadiobutton", command=self.toggle_reason_entry)
        hadir_radio.place(relx=0.4, rely=0.3, anchor=tk.CENTER)
        tidak_hadir_radio = ttk.Radiobutton(frame6, text="Tidak Hadir", value="Tidak Hadir", variable=self.attendance_status, style="TRadiobutton", command=self.toggle_reason_entry)
        tidak_hadir_radio.place(relx=0.6, rely=0.3, anchor=tk.CENTER)

        self.reason_entry = tk.Entry(frame6, font=self.font2, fg='#FFFFFF', bg='#121111', insertbackground='#fff', width=30)
        self.reason_entry.place(relx=0.5, rely=0.5, anchor=tk.CENTER)
        self.reason_entry.grid_remove()  # Sembunyikan entri alasan ketidakhadiran pada awal

        save_attendance_button = tk.Button(frame6, command=self.save_attendance, font=self.font2, text='Save', fg='#fff', bg='#00965d', activebackground='#006e44', width=12)
        save_attendance_button.place(relx=0.5, rely=0.6, anchor=tk.CENTER)  # Posisi awal tombol

        # Fungsi untuk mengatur ulang posisi tombol "Save" berdasarkan posisi dan ukuran kotak entry
    def position_save_button(event):
        entry_height = self.reason_entry.winfo_height()
        button_height = save_attendance_button.winfo_height()
        entry_y = self.reason_entry.winfo_y()
        save_attendance_button.place_configure(relx=0.5, rely=(entry_y + entry_height + 20) / frame6.winfo_height(), anchor=tk.CENTER)

        self.reason_entry.bind("<Configure>", position_save_button)

        self.add_image_to_frame(self.root)  # Menampilkan gambar di frame input start date dan week number

    def toggle_reason_entry(self):
        if self.attendance_status.get() == "Tidak Hadir":
            self.reason_entry.grid()  # Tampilkan entri alasan ketidakhadiran
        else:
            self.reason_entry.grid_remove()  # Sembunyikan entri alasan ketidakhadiran

    def save_attendance(self):
        attendance_status = self.attendance_status.get()
        reason = self.reason_entry.get() if attendance_status == "Tidak Hadir" else ""

        data = self.load_data()
        if self.current_user in data:
            attendance_data = {
            "attendance_status": attendance_status,
            "reason": reason
            }
            data[self.current_user]["attendance"] = attendance_data
            self.save_data(data)
            messagebox.showinfo('Success', 'Presensi berhasil disimpan.')
        else:
            messagebox.showerror('Error', 'Invalid username.')
    def clear_frame(self):
        for widget in self.root.winfo_children():
            widget.destroy()

if __name__ == '__main__':
    root = tk.Tk()
    app = LoginApp(root)                                                                                                                          
    root.mainloop()
